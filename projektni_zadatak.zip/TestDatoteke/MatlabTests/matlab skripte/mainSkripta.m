% Mora se pokrenuti iz foldera u kom se nalazi

napraviTestFajl(2, '.\..\2_in.txt', '.\..\2_out.txt');
napraviTestFajl(4, '.\..\4_in.txt', '.\..\4_out.txt');
napraviTestFajl(8, '.\..\8_in.txt', '.\..\8_out.txt');
napraviTestFajl(16, '.\..\16_in.txt', '.\..\16_out.txt');
napraviTestFajl(32, '.\..\32_in.txt', '.\..\32_out.txt');
napraviTestFajl(64, '.\..\64_in.txt', '.\..\64_out.txt');
napraviTestFajl(128, '.\..\128_in.txt', '.\..\128_out.txt');
napraviTestFajl(256, '.\..\256_in.txt', '.\..\256_out.txt');
napraviTestFajl(512, '.\..\512_in.txt', '.\..\512_out.txt');
napraviTestFajl(1024, '.\..\1024_in.txt', '.\..\1024_out.txt');
napraviTestFajl(2048, '.\..\2048_in.txt', '.\..\2048_out.txt');