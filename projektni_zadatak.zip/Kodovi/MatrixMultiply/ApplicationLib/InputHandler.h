#ifndef _INPUT_HANDLER_H_
#define _INPUT_HANDLER_H_

#include "ApplicationData.h"

void parseInputFile();

#endif