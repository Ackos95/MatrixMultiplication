#ifndef _OUTPUT_HANDLER_H_
#define _OUTPUT_HANDLER_H_

#include "ApplicationData.h"

void writeToFile();

#endif