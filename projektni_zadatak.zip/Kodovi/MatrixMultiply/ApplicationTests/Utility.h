#ifndef _TESTS_UTILITY_H_
#define _TESTS_UTILITY_H_

/// helper function to test writing into output file
bool isFilesEqual(const char *, const char *);

#endif